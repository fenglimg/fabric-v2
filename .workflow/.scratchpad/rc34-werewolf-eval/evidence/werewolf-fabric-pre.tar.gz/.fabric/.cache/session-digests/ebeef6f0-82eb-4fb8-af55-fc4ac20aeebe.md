# 当前Spy谁是卧底历史记录测试反馈了一个问题，比如第一轮有ABCDE，第一轮A死亡了，A的弃票没有记录在弃牌堆里，你看看？

_Session: ebeef6f0-82eb-4fb8-af55-fc4ac20aeebe · written: 2026-05-21T06:34:47.943Z_

## User messages (top 10)

- 当前Spy谁是卧底历史记录测试反馈了一个问题，比如第一轮有ABCDE，第一轮A死亡了，A的弃票没有记录在弃牌堆里，你看看？
- 当前Spy谁是卧底历史记录测试反馈了一个问题，比如第一轮有ABCDE，第一轮A死亡了，A的弃票没有记录在弃牌堆里，你看看？

## Edits

_(no edits captured)_
