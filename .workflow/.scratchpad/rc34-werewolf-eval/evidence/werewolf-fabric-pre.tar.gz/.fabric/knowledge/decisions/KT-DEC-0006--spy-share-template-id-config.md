---
id: KT-DEC-0006
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:17:21.314Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

卧底分享走 spy_game_seat 模板占位，template_id 通过配置注入而非硬编码；分享 payload 沿用统一模板字段填充约定，新增玩法分享时也走同一模式。src=de4df22a

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log. Origin: commit de4df22a (feat(spy): 卧底分享接入 spy_game_seat 与模板占位及 template_id 配置).

## Evidence

Recent paths:

- assets/Bundles/SpyGame
- assets/Bundles/Social

Notes:

- 卧底分享走 spy_game_seat 模板占位，template_id 通过配置注入而非硬编码；分享 payload 沿用统一模板字段填充约定，新增玩法分享时也走同一模式。src=de4df22a
