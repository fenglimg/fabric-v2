---
id: KT-DEC-0001
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:17:24.004Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

好友邀请与最近好友列表需要补齐卧底房展示，且支持站外分享；社交侧 UI 应识别多种桌游房类型，不能只硬编码狼人。src=749b15fa

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log. Origin: commit 749b15fa (feat(social): 好友邀请与最近好友补齐卧底房展示与站外分享).

## Evidence

Recent paths:

- assets/Bundles/Social
- assets/Bundles/SpyGame

Notes:

- 好友邀请与最近好友列表需要补齐卧底房展示，且支持站外分享；社交侧 UI 应识别多种桌游房类型，不能只硬编码狼人。src=749b15fa
