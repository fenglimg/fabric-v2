---
id: KT-DEC-0003
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:12:34.219Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

桌游通用房间字段下沉至 GameCenterModel，避免共用弹窗继续依赖狼人私有 model；同步补齐 recover 与 RoomInfoPush 的同步路径，并加回归测试。共用 UI 与状态都从 GameCenter 取，狼人/卧底等具体玩法只持有玩法私有字段。src=fdd059c8

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log analysis. Origin: commit fdd059c8 (fix(gamecenter): 统一桌游房间基础信息读取). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/GameCenter

Notes:

- 桌游通用房间字段下沉至 GameCenterModel，避免共用弹窗继续依赖狼人私有 model；同步补齐 recover 与 RoomInfoPush 的同步路径，并加回归测试。共用 UI 与状态都从 GameCenter 取，狼人/卧底等具体玩法只持有玩法私有字段。src=fdd059c8
