---
id: KT-DEC-0004
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:12:48.909Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

把共享桌游 push 的 rid 过滤从 GameSocket 收口到 GameCenter，避免底层 socket 抢写或残留 rid 触发静默丢弃；统一被踢、重登、reset 等链路 ws.rid 的清理时机；rid 维护是 GameCenter 的职责，socket 层不再独立判断。src=71706b3e

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log analysis. Origin: commit 71706b3e (fix(game-center): 收拢 rid 维护并上移串房过滤). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/GameCenter
- assets/Bundles/Common

Notes:

- 把共享桌游 push 的 rid 过滤从 GameSocket 收口到 GameCenter，避免底层 socket 抢写或残留 rid 触发静默丢弃；统一被踢、重登、reset 等链路 ws.rid 的清理时机；rid 维护是 GameCenter 的职责，socket 层不再独立判断。src=71706b3e
