---
id: KT-DEC-0002
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:12:45.042Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

只知道 rid 的入房场景统一走 GameCenter.joinByRid：先拉房间信息再解析玩法，再走对应桌游进房链路；广播、外部分享等所有入口共用同一路径，避免每入口重复实现玩法解析。src=3bdff299

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log analysis. Origin: commit 3bdff299 (fix(game): 支持按 rid 加入桌游房并细化 WS 日志). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/GameCenter

Notes:

- 只知道 rid 的入房场景统一走 GameCenter.joinByRid：先拉房间信息再解析玩法，再走对应桌游进房链路；广播、外部分享等所有入口共用同一路径，避免每入口重复实现玩法解析。src=3bdff299
