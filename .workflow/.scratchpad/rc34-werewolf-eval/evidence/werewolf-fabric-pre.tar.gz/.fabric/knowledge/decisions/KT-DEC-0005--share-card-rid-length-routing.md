---
id: KT-DEC-0005
type: decisions
maturity: draft
layer: team
created_at: 2026-05-13T11:17:11.197Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

聊天分享房卡进房按 rid 长度分流：派对房用三位短号，桌游/小游戏房用七位 rid 走 GameCenter；不同短号长度路由不同入房链路，避免一刀切错路由。src=80d1a7dd

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log. Origin: commit 80d1a7dd (fix(social): 聊天分享房卡进房支持派对三位短号与七位小游戏房 GameCenter 分流).

## Evidence

Recent paths:

- assets/Bundles/Social

Notes:

- 聊天分享房卡进房按 rid 长度分流：派对房用三位短号，桌游/小游戏房用七位 rid 走 GameCenter；不同短号长度路由不同入房链路，避免一刀切错路由。src=80d1a7dd
