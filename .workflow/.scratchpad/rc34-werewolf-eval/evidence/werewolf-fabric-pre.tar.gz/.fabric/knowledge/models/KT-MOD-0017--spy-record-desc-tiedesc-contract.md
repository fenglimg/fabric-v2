---
id: KT-MOD-0017
type: models
maturity: draft
layer: team
created_at: 2026-05-21T04:37:21.791Z
source_sessions: ["4cba81f8-f5b6-4ce9-aa13-deac1a879b12"]
proposed_reason: new-dependency-or-pattern
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Bundles/SpyGame/Script/Record/**/*.ts", "assets/Bundles/SpyGame/Script/Room/SpyPlayerListLayer.ts", "assets/Bundles/SpyGame/Script/Room/SpyPlayerControl.ts"]
intent_clues: ["编辑谁是卧底 Record/Replay 相关代码时", "处理 IDescRecord.descs / tieDescs 字段时", "NOT for live 游戏阶段渲染 (renderPKPlayers 用 SpyGamer.isTieGamer，是另一套语义)"]
tech_stack: ["typescript", "cocos-creator", "spy-game"]
impact: ["误用 tieDescs.isTieGamer 作 PK 参与者标记会少显示一张 PK 卡 + 少一条 PK 发言", "PK 轮丢弃非 PK 旁观者条目会让 D/E 座位空白，体验异常"]
must_read_if: "改动 SpyGameRecordDetailModel 或 PK 轮渲染（SpyPlayerListLayer.renderRecordRound / SpyPlayerControl.renderRecordDisplay）"
---

## Summary

用户排查回放 UI PK 轮只显示 2 人但实际 3 人入 PK 的问题。澄清 spy 协议契约后用户主张这不是"坑"而是字段语义没理清，归档为数据契约模型 + 回放装配规则。最终客户端按 descs.isTieGamer 作为 PK 参与者权威源、tieDescs 提供显示数据；非 PK 旁观者也保留以免座位空白。

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Session goal: 修复谁是卧底对局记录回放在 PK 轮只浮起 2 张卡（实际有 3 人入 PK）的显示缺陷。
Turning point: 对比 round=1 的 descs/tieDescs 实际数据，确认 `isTieGamer` 在两个数组里语义不同 —— descs 标"进入 PK"，tieDescs 标"PK 后仍平票"，0 票被淘汰的 PK 参与者会在 tieDescs 里丢失 isTieGamer:true。
用户澄清：这不是 server bug 也不是"坑"，是客户端没按契约用对字段；正确装配方式是 descs 提供参与者集合 + tieDescs 提供显示数据 + 非 PK 旁观者保留避免座位空白。
Result: SpyGameRecordDetailModel.buildPkRoundDescs 按本契约重写，新增测试覆盖三人 PK + 一人被 0 票淘汰的场景。

## Evidence

Recent paths:

- assets/Bundles/SpyGame/Script/Record/SpyGameRecordDetailModel.ts
- assets/Bundles/SpyGame/Script/Room/SpyBottomToolBar.ts
- assets/Bundles/SpyGame/Script/Room/SpyPlayerListLayer.ts
- assets/Bundles/SpyGame/Script/Room/SpyPlayerControl.ts
- tests/assets/Bundles/SpyGame/Script/Record/__tests__/SpyGameRecordDetailModel.test.ts
- assets/Proto/wepie-proto-static.d.ts

Notes:

- 用户排查回放 UI PK 轮只显示 2 人但实际 3 人入 PK 的问题。澄清 spy 协议契约后用户主张这不是"坑"而是字段语义没理清，归档为数据契约模型 + 回放装配规则。最终客户端按 descs.isTieGamer 作为 PK 参与者权威源、tieDescs 提供显示数据；非 PK 旁观者也保留以免座位空白。
