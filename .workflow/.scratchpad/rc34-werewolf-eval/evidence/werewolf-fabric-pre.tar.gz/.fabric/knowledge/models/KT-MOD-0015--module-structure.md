---
id: KT-MOD-0015
type: model
layer: team
maturity: verified
layer_reason: "project artifact (deterministic init scan)"
created_at: 2026-05-18T08:03:02.759Z
tags: []
relevance_scope: narrow
relevance_paths: ["packages/**/package.json"]
---

# Module structure

## [MISSION_STATEMENT]

梳理 werewolf-minigame 的高层 module 布局与主要 entry point。

## [CONTEXT_INFO]

文件总数：28849
最大目录深度：17

关键目录：
- assets/Bundles/Activity/LoveRelativityAct/Script/components
- assets/Bundles/Activity/LoveRelativityAct/Script/pages
- assets/RemoteBundles/ActivityRemote/LoveRelativityAct/Prefab/pages
- assets/RemoteBundles/ActivityRemote/LoveRelativityAct/Texture/components
- assets/RemoteBundles/ActivityRemote/LoveRelativityAct/Texture/pages
- build-templates/android/frameworks/cocos2d-x/cocos/platform/android/java/src
- build-templates/android/frameworks/cocos2d-x/cocos/platform/android/libcocos2dx/src
- build-templates/android/frameworks/cocos2d-x/external/sources/google-breakpad/src
- build-templates/android/frameworks/cocos2d-x/external/sources/pvmp3dec/src
- build-templates/android/frameworks/runtime-src/proj.android-studio/app
- build-templates/android/frameworks/runtime-src/proj.android-studio/app/src
- build-templates/android/frameworks/runtime-src/proj.android-studio/citypickerview/src

Entry points：
- (no entry points detected)
