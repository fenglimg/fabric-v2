---
id: KT-MOD-0007
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:12:57.334Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人杀整体架构为 MVVM + MobX 响应式 + 事件总线，分 UI/ViewModel/Business/Server/Store 五层：View 用 @observer + @autorunAfterEnable 响应数据；WolfGameManager 负责会话与 Push 路由，WolfGameModel 是唯一数据源；GameSocket 处理自定义帧并将推送与响应分离。src=docs/wolfgame-reference/01-architecture-overview.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs analysis. Origin: docs/wolfgame-reference/01-architecture-overview.md — canonical layered architecture description. No live session — see doc for full context.

## Evidence

Recent paths:

- docs/wolfgame-reference/01-architecture-overview.md

Notes:

- 狼人杀整体架构为 MVVM + MobX 响应式 + 事件总线，分 UI/ViewModel/Business/Server/Store 五层：View 用 @observer + @autorunAfterEnable 响应数据；WolfGameManager 负责会话与 Push 路由，WolfGameModel 是唯一数据源；GameSocket 处理自定义帧并将推送与响应分离。src=docs/wolfgame-reference/01-architecture-overview.md
