---
id: KT-MOD-0001
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:18:28.211Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

GameCenter 模块概览：作为多桌游（狼人/卧底/其他）的统一会话与房间数据中枢；shared 房间字段下沉至 GameCenterModel，rid 维护、in-game 判定、按 rid 入房等公共路径都收口在此。src=docs/game-center/README.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/game-center/README.md.

## Evidence

Recent paths:

- docs/game-center/README.md

Notes:

- GameCenter 模块概览：作为多桌游（狼人/卧底/其他）的统一会话与房间数据中枢；shared 房间字段下沉至 GameCenterModel，rid 维护、in-game 判定、按 rid 入房等公共路径都收口在此。src=docs/game-center/README.md
