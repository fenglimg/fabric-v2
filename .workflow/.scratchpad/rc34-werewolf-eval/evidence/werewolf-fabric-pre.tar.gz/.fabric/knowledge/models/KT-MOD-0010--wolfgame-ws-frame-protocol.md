---
id: KT-MOD-0010
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:17:32.503Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人游戏自定义 WebSocket 帧协议：推送 (push) 与响应 (response) 分离处理；帧结构、cmd 路由、自定义编解码细节见文档。src=docs/wolfgame-reference/03-network-protocol.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/03-network-protocol.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/03-network-protocol.md

Notes:

- 狼人游戏自定义 WebSocket 帧协议：推送 (push) 与响应 (response) 分离处理；帧结构、cmd 路由、自定义编解码细节见文档。src=docs/wolfgame-reference/03-network-protocol.md
