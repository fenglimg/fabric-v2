---
id: KT-MOD-0008
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:13:03.305Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人游戏主流程状态机：None(0) → Prepare(1) → Deal(2) → Night(3) ⇄ Day(4) → Over(5)。WolfGameModel._gamePhase 由 _state 经 mapStateToGameState() 派生，阶段切换驱动 UI 主层级转换；具体状态码（女巫询问、轮流发言、投票、平票发言等）按阶段细分。src=docs/wolfgame-reference/02-game-flow-state-machine.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs analysis. Origin: docs/wolfgame-reference/02-game-flow-state-machine.md — canonical state-code mapping. No live session — see doc for full context.

## Evidence

Recent paths:

- docs/wolfgame-reference/02-game-flow-state-machine.md

Notes:

- 狼人游戏主流程状态机：None(0) → Prepare(1) → Deal(2) → Night(3) ⇄ Day(4) → Over(5)。WolfGameModel._gamePhase 由 _state 经 mapStateToGameState() 派生，阶段切换驱动 UI 主层级转换；具体状态码（女巫询问、轮流发言、投票、平票发言等）按阶段细分。src=docs/wolfgame-reference/02-game-flow-state-machine.md
