---
id: KT-MOD-0014
type: model
layer: team
maturity: verified
layer_reason: "project artifact (deterministic init scan)"
created_at: 2026-05-18T08:03:02.759Z
tags: []
relevance_scope: narrow
relevance_paths: ["package.json"]
---

# Tech stack: cocos-creator unknown / typescript-component

## [MISSION_STATEMENT]

记录 werewolf-minigame 所使用的主要 tech stack 与运行时面。

## [CONTEXT_INFO]

Framework：cocos-creator unknown / typescript-component
主要文件后缀：.json (5702), .meta (4782), .png (4246), .js (4068), .h (3144)
证据：
- project.config.json
