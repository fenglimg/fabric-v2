---
id: KT-MOD-0002
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:17:54.409Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展 - 数据模型规范：Info 类结构、字段设计、角色判断逻辑；扩展数据模型时按规范定义字段与角色识别。src=docs/voice-room-extension/spec-data-model.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/spec-data-model.md.

## Evidence

Recent paths:

- docs/voice-room-extension/spec-data-model.md

Notes:

- 语音房扩展 - 数据模型规范：Info 类结构、字段设计、角色判断逻辑；扩展数据模型时按规范定义字段与角色识别。src=docs/voice-room-extension/spec-data-model.md
