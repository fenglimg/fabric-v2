---
id: KT-MOD-0006
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:17:35.202Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人核心数据模型：GamePlayer / RoleMarkStore / ConfigStore / Store 等 MobX observable 对象的字段、关系与生命周期。src=docs/wolfgame-reference/04-data-models.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/04-data-models.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/04-data-models.md

Notes:

- 狼人核心数据模型：GamePlayer / RoleMarkStore / ConfigStore / Store 等 MobX observable 对象的字段、关系与生命周期。src=docs/wolfgame-reference/04-data-models.md
