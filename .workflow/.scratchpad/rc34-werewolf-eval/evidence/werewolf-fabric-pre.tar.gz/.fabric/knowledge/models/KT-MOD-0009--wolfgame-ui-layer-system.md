---
id: KT-MOD-0009
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:17:38.217Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人 UI 系统分层：GameRoom → HeaderLayer / PlayerListLayer / CenterLayer / FooterLayer / HoverLayer；View 用 @observer + @autorunAfterEnable 响应 Model 变化。src=docs/wolfgame-reference/05-ui-system.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/05-ui-system.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/05-ui-system.md

Notes:

- 狼人 UI 系统分层：GameRoom → HeaderLayer / PlayerListLayer / CenterLayer / FooterLayer / HoverLayer；View 用 @observer + @autorunAfterEnable 响应 Model 变化。src=docs/wolfgame-reference/05-ui-system.md
