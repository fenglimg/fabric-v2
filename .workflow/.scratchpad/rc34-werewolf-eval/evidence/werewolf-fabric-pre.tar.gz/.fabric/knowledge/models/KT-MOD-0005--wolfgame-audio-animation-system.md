---
id: KT-MOD-0005
type: models
maturity: draft
layer: team
created_at: 2026-05-13T11:17:41.819Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人音频/动画：单例 audioUtil (AudioUtil.ts) 统一管理音效；音效按阶段事件触发（CloseEye→EnterNight、Vote→Vote、WolfKillBgm 夜晚 loop 等）；新增音效走映射表挂阶段而非散点调用。src=docs/wolfgame-reference/06-audio-animation.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/06-audio-animation.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/06-audio-animation.md

Notes:

- 狼人音频/动画：单例 audioUtil (AudioUtil.ts) 统一管理音效；音效按阶段事件触发（CloseEye→EnterNight、Vote→Vote、WolfKillBgm 夜晚 loop 等）；新增音效走映射表挂阶段而非散点调用。src=docs/wolfgame-reference/06-audio-animation.md
