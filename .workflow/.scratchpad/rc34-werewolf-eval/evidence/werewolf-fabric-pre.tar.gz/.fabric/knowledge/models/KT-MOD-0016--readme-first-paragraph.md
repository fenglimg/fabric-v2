---
id: KT-MOD-0016
type: model
layer: team
maturity: verified
layer_reason: "project artifact (deterministic init scan)"
created_at: 2026-05-18T08:03:02.759Z
tags: []
relevance_scope: broad
relevance_paths: []
---

# README first paragraph

## [MISSION_STATEMENT]

把 README 的标题与首段保留为项目对外的 canonical elevator pitch。

## [CONTEXT_INFO]

来源：README.md（269 行，quality=ok）

摘录：
> ```text
> |- Core     // 核心层：底层通用代码，不依赖具体的游戏引擎，也不依赖具体某个游戏的逻辑
> |   |- Lib     第三方库：通用的，不依赖具体游戏引擎的第三方库
> |   |- ObjectPool   对象池定义，以及基础的管理方法
> |   |- Event
> |   |- Utils
> |   |- Interface    通用的工具类的实现接口，资源管理，UI管理，网络管理等
> |- Cocos    // Cocos引擎层：Cocos通用的工具方法，或者通用组件，UI框架。只可以依赖Core层
> |   |- Lib     第三方库：依赖Cocos引擎的第三方库，目前已知的有FGUI-Cocos, Mobx-Cocos
> |   |- UI       // UI框架
> |   |- ObjectPool   依赖引擎的对象池实现，比如预制体对象池
> |   |- Utils
> |- Business // 业务层：具体游戏项目的业务逻辑，只处理数据，不依赖引擎，也不依赖表现层的代码，只可以依赖Core层
> |   |- Models
> |   |- Services
> |   |- GamePlay
> |   |- Managers
> |   |- Utils
> |   |- Constants
> |   |- Defines
> |- Presentation // 表现层，可以依赖所有层
> |   |- UIFlow       // 通用的UI业务处理流程，比如二次确认逻辑
> |   |- Views
> |   |- UIUtils
> |   |- Constants    // 仅表现层用到的常量，比如一些本地图片地址，颜色参数等
> |   |- Defines
> |- Lib   第三方库: 对第三方库不加区分全部放到这个文件夹下(目前项目按照这个方式划分)
> ```
