---
id: KT-PRO-0001
type: processes
maturity: draft
layer: team
created_at: 2026-05-13T11:18:30.512Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

Android 平台迁移指南：平台适配差异、API 替换映射、权限/支付/音频/录音等模块的 Android 专项处理与排坑清单。src=ANDROID_MIGRATION.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: ANDROID_MIGRATION.md (top-level).

## Evidence

Recent paths:

- ANDROID_MIGRATION.md

Notes:

- Android 平台迁移指南：平台适配差异、API 替换映射、权限/支付/音频/录音等模块的 Android 专项处理与排坑清单。src=ANDROID_MIGRATION.md
