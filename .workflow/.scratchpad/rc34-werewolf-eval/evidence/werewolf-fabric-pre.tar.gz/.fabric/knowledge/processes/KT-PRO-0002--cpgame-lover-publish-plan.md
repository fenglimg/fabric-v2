---
id: KT-PRO-0002
type: processes
maturity: draft
layer: team
created_at: 2026-05-13T11:18:20.628Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

CP 玩法 Lover 公布流程计划：发布时机、发布动画/通知路径、公屏与座位侧 UI 同步；公布是触发型事件，状态由推送驱动而非客户端独立推进。src=docs/voice-room/cpgame/CpGameLoverPublishPlan.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room/cpgame/CpGameLoverPublishPlan.md.

## Evidence

Recent paths:

- docs/voice-room/cpgame/CpGameLoverPublishPlan.md

Notes:

- CP 玩法 Lover 公布流程计划：发布时机、发布动画/通知路径、公屏与座位侧 UI 同步；公布是触发型事件，状态由推送驱动而非客户端独立推进。src=docs/voice-room/cpgame/CpGameLoverPublishPlan.md
