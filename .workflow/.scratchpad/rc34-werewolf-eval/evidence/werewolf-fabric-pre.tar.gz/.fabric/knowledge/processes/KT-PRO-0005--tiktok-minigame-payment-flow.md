---
id: KT-PRO-0005
type: processes
maturity: draft
layer: team
created_at: 2026-05-13T11:18:24.467Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

抖音小游戏支付流程：用户点购买 → PaymentHelper.payGoodsItem → Payment.payGameItem → api.createMiOrder (服务端返 order_id/paySig/signData) → PaymentAgentTiktok.requestMidasPaymentGameItem (Android tt.requestGamePayment / iOS tt.openAwemeCustomerService) → 支付完成回调与发货。src=docs/payment-flow-analysis.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/payment-flow-analysis.md.

## Evidence

Recent paths:

- docs/payment-flow-analysis.md

Notes:

- 抖音小游戏支付流程：用户点购买 → PaymentHelper.payGoodsItem → Payment.payGameItem → api.createMiOrder (服务端返 order_id/paySig/signData) → PaymentAgentTiktok.requestMidasPaymentGameItem (Android tt.requestGamePayment / iOS tt.openAwemeCustomerService) → 支付完成回调与发货。src=docs/payment-flow-analysis.md
