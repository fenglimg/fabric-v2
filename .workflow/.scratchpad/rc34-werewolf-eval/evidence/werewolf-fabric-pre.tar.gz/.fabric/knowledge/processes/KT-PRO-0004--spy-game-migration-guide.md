---
id: KT-PRO-0004
type: processes
maturity: draft
layer: team
created_at: 2026-05-13T11:17:48.314Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

从狼人玩法迁移/复刻到卧底玩法的指南：共用基础设施（GameCenter、网络、UI 框架）保留，玩法私有字段下沉到各自 Model；迁移路径与对应映射见文档。src=docs/wolfgame-reference/08-spy-game-migration-guide.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/08-spy-game-migration-guide.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/08-spy-game-migration-guide.md

Notes:

- 从狼人玩法迁移/复刻到卧底玩法的指南：共用基础设施（GameCenter、网络、UI 框架）保留，玩法私有字段下沉到各自 Model；迁移路径与对应映射见文档。src=docs/wolfgame-reference/08-spy-game-migration-guide.md
