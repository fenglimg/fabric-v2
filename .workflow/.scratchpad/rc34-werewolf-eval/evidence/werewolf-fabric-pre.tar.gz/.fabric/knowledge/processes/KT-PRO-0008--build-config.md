---
id: KT-PRO-0008
type: process
layer: team
maturity: verified
layer_reason: "project artifact (deterministic init scan)"
created_at: 2026-05-18T08:03:02.759Z
tags: []
relevance_scope: narrow
relevance_paths: ["package.json", "tsconfig.json"]
---

# Build configuration

## [MISSION_STATEMENT]

记录 werewolf-minigame 所依赖的、确定性的 build / bootstrap 配置。

## [BUSINESS_LOGIC_CHUNKS]

1. 探测 framework：`cocos-creator`。
2. 按声明顺序读取 configuration files。
3. 在生成新代码之前，尊重 compiler / bundler 的边界。
4. 把 config 漂移视为 fact-check 信号 —— 修改后重新运行 `fab scan`。

## [CONTEXT_INFO]

Framework：cocos-creator

Configuration files：
- project.config.json
- package.json
- tsconfig.json
