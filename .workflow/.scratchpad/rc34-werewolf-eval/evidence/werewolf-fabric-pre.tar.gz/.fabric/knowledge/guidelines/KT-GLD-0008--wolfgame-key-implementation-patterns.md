---
id: KT-GLD-0008
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:17:44.795Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

狼人关键实现模式：手动单例 Manager（非 Cocos 组件，构造时注册 push handler 与 BizEvents 监听，生命周期独立场景）；会话入口 create/match/join/recover 走统一流程；Push 路由集中处理。src=docs/wolfgame-reference/07-implementation-patterns.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/wolfgame-reference/07-implementation-patterns.md.

## Evidence

Recent paths:

- docs/wolfgame-reference/07-implementation-patterns.md

Notes:

- 狼人关键实现模式：手动单例 Manager（非 Cocos 组件，构造时注册 push handler 与 BizEvents 监听，生命周期独立场景）；会话入口 create/match/join/recover 走统一流程；Push 路由集中处理。src=docs/wolfgame-reference/07-implementation-patterns.md
