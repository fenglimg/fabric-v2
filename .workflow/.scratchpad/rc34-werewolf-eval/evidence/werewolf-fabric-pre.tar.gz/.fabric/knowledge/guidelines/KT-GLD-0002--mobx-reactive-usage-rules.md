---
id: KT-GLD-0002
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:13:04.769Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

MobX 使用规范（项目移植到 Cocos Creator 2.x 的 MobX 4/5 兼容版）：状态 → 推导 → 副作用单向流；@observable 标记状态、@computed 必须纯函数无副作用、@action 批量提交修改只触发一次重算；UI 用 @observer + @autorunAfterEnable 响应。src=docs/wolfgame-reference/09-mobx-patterns.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs analysis. Origin: docs/wolfgame-reference/09-mobx-patterns.md — project-wide MobX usage rules. No live session — see doc for full context.

## Evidence

Recent paths:

- docs/wolfgame-reference/09-mobx-patterns.md

Notes:

- MobX 使用规范（项目移植到 Cocos Creator 2.x 的 MobX 4/5 兼容版）：状态 → 推导 → 副作用单向流；@observable 标记状态、@computed 必须纯函数无副作用、@action 批量提交修改只触发一次重算；UI 用 @observer + @autorunAfterEnable 响应。src=docs/wolfgame-reference/09-mobx-patterns.md
