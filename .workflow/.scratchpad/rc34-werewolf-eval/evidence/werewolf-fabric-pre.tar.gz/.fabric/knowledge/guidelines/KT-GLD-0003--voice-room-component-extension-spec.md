---
id: KT-GLD-0003
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:18:07.416Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展 - 组件扩展规范：SeatView / WidgetView 快速扩展参考；自定义组件时遵循扩展点而非直接覆盖基类。src=docs/voice-room-extension/spec-component-extensions.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/spec-component-extensions.md.

## Evidence

Recent paths:

- docs/voice-room-extension/spec-component-extensions.md

Notes:

- 语音房扩展 - 组件扩展规范：SeatView / WidgetView 快速扩展参考；自定义组件时遵循扩展点而非直接覆盖基类。src=docs/voice-room-extension/spec-component-extensions.md
