---
id: KT-GLD-0004
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:17:51.749Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展开发导航：按 spec-data-model / spec-feature-plugin / spec-viewmodel / spec-view / spec-seat-system / spec-component-extensions / spec-workflows 七个 spec 拆分职责；按开发阶段（数据 → Feature → ViewModel → View → 集成）查文档。src=docs/voice-room-extension/GUIDE.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/GUIDE.md.

## Evidence

Recent paths:

- docs/voice-room-extension/GUIDE.md

Notes:

- 语音房扩展开发导航：按 spec-data-model / spec-feature-plugin / spec-viewmodel / spec-view / spec-seat-system / spec-component-extensions / spec-workflows 七个 spec 拆分职责；按开发阶段（数据 → Feature → ViewModel → View → 集成）查文档。src=docs/voice-room-extension/GUIDE.md
