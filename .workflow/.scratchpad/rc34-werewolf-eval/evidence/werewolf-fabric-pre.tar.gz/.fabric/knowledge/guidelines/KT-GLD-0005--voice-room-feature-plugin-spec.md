---
id: KT-GLD-0005
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:17:57.081Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展 - Feature 插件规范：Feature 类、SyncUtil、推送处理；新增功能走 Feature 插件而非直接修改语音房核心。src=docs/voice-room-extension/spec-feature-plugin.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/spec-feature-plugin.md.

## Evidence

Recent paths:

- docs/voice-room-extension/spec-feature-plugin.md

Notes:

- 语音房扩展 - Feature 插件规范：Feature 类、SyncUtil、推送处理；新增功能走 Feature 插件而非直接修改语音房核心。src=docs/voice-room-extension/spec-feature-plugin.md
