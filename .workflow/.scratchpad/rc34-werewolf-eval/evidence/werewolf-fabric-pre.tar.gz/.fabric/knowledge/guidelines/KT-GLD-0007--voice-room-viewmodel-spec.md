---
id: KT-GLD-0007
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:17:59.749Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展 - ViewModel 规范：ViewModel 类、事件监听、业务方法；ViewModel 隔离 View 与 Model，封装 UI 业务逻辑。src=docs/voice-room-extension/spec-viewmodel.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/spec-viewmodel.md.

## Evidence

Recent paths:

- docs/voice-room-extension/spec-viewmodel.md

Notes:

- 语音房扩展 - ViewModel 规范：ViewModel 类、事件监听、业务方法；ViewModel 隔离 View 与 Model，封装 UI 业务逻辑。src=docs/voice-room-extension/spec-viewmodel.md
