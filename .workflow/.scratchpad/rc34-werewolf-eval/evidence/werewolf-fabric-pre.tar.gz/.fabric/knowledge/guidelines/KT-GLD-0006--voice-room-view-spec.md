---
id: KT-GLD-0006
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:18:02.056Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

语音房扩展 - View 规范：View 类、委托创建、状态恢复；View 只响应 ViewModel，不直接持有业务状态。src=docs/voice-room-extension/spec-view.md

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from docs. Origin: docs/voice-room-extension/spec-view.md.

## Evidence

Recent paths:

- docs/voice-room-extension/spec-view.md

Notes:

- 语音房扩展 - View 规范：View 类、委托创建、状态恢复；View 只响应 ViewModel，不直接持有业务状态。src=docs/voice-room-extension/spec-view.md
