---
id: KT-GLD-0001
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-13T11:12:53.362Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: new-dependency-or-pattern
tags: []
---

## Summary

"是否在游戏中"必须用 GameCenter 判定，不能直接读狼人私有 isInGame；否则卧底房等其他桌游内仍会弹出签到/新手/活动弹窗，桌游送礼等流程也会判错在局。src=2a50eacb,8edfd3d7

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

Imported from git log analysis. Origin: commits 2a50eacb (fix(home)) and 8edfd3d7 (fix(gift)) — both reinforce GameCenter as the authoritative in-game check across werewolf/spy/other table games. No live session — see commit bodies for full context.

## Evidence

Recent paths:

- assets/Bundles/Main
- assets/Bundles/Gift

Notes:

- "是否在游戏中"必须用 GameCenter 判定，不能直接读狼人私有 isInGame；否则卧底房等其他桌游内仍会弹出签到/新手/活动弹窗，桌游送礼等流程也会判错在局。src=2a50eacb,8edfd3d7
