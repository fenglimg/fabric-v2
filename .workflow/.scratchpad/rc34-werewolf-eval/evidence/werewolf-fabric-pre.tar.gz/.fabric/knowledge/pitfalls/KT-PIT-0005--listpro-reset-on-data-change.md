---
id: KT-PIT-0005
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:17:27.073Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

ListPro 虚拟列表在数据源变更时必须主动重置滚动位置，否则旧滚动偏移会让新数据展示错位。src=4c1b6ad5

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log. Origin: commit 4c1b6ad5 (fix: ListPro虚拟列表在数据源变更的时候重置位置).

## Evidence

Recent paths:

- assets/Script/UI/ListPro

Notes:

- ListPro 虚拟列表在数据源变更时必须主动重置滚动位置，否则旧滚动偏移会让新数据展示错位。src=4c1b6ad5
