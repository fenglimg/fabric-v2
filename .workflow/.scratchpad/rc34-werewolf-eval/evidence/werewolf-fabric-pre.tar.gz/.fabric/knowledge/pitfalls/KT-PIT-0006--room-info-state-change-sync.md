---
id: KT-PIT-0006
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:17:07.343Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

RoomInfo 推送触发 roomState 变化时必须主动同步最新游戏数据；否则房间状态变更后客户端未及时拉数据，UI 与服务端状态不同步。src=02085af9

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log. Origin: commit 02085af9 (fix(spy-game): RoomInfo 推送触发 roomState 变化时主动同步).

## Evidence

Recent paths:

- assets/Bundles/SpyGame

Notes:

- RoomInfo 推送触发 roomState 变化时必须主动同步最新游戏数据；否则房间状态变更后客户端未及时拉数据，UI 与服务端状态不同步。src=02085af9
