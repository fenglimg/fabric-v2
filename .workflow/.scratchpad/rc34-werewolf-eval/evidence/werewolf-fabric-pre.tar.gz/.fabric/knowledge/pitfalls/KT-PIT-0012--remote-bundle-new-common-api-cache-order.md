---
id: KT-PIT-0012
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-19T07:05:02.039Z
source_sessions: ["67063371-304e-4f53-83af-a2466bcf0b07"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Bundles/SpyGame/**/*.ts", "assets/Script/Business/SpyGame/**/*.ts"]
intent_clues: ["when remote bundle calls new shared/common API", "when TypeError says method is not a function after hot update", "NOT for same-bundle private helper calls"]
tech_stack: ["typescript", "cocos-creator", "wechat-minigame"]
impact: ["runtime TypeError only under stale cache or split-package publish order", "remote UI can fail to open before fallback path runs"]
must_read_if: "changing SpyGame remote bundle code to call newly added methods in assets/Script/Business/SpyGame"
---

## Summary

用户反馈 SpyGameRoomUI 调用新增 playBgmByPhase 后运行时报错；后确认可能是开发缓存导致，小游戏线上通常同批包不会出现，但排查思路值得沉淀。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

为 SpyGameRoomUI 接入阶段 BGM 和短音效后，运行时报 TypeError: SpyGameSoundUtil.playBgmByPhase is not a function。
关键判断是报错发生在 SpyGame 远程包 UI 调用公共脚本新增方法时，运行时可能拿到旧公共包或缓存旧模块。
即使最终由缓存导致，本次排查明确了跨 bundle API 变更的诊断路径：先判断调用方/被调用方所属 bundle，再验证运行时是否同批更新。

## Evidence

Recent paths:

- assets/Bundles/SpyGame/Script/SpyGameRoomUI.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Script/Business/SpyGame/SpyGameSoundUtil.ts
- assets/Script/Business/SpyGame/SpyGameConst.ts

Notes:

- 用户反馈 SpyGameRoomUI 调用新增 playBgmByPhase 后运行时报错；后确认可能是开发缓存导致，小游戏线上通常同批包不会出现，但排查思路值得沉淀。
