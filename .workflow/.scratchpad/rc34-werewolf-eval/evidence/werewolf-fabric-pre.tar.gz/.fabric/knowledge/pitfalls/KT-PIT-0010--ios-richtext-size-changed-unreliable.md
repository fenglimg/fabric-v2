---
id: KT-PIT-0010
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-18T10:32:33.021Z
source_sessions: ["werewolf-2026-05-18-spy-msg-ios-fix"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: broad
relevance_paths: []
---

## Summary

commit 3c0c411 删除了 SpyRoomMsgItem 首渲的同步测量、改纯依赖 RichText size_changed 异步纠正。在 iOS 14 Pro + iOS 16/17 上公屏消息频繁塌成单行；安卓/Web 正常。诊断后确定双重陷阱：iOS WKWebView Canvas2D measureText 同帧净 contentSize 变化为 0 时 size_changed 不触发，叠加 ListPro 滚动期 onChildSizeChanged 直接 return。改用 B+C 方案：保留复用路径的强同步 applyMsgSize + 恢复首渲同步兜底（不写回 data.height）+ scheduleOnce(0) 下一帧主动重测绕开事件依赖；经实机测试有效。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 还原或重做 commit 3c0c411，修复 iOS 14 Pro + iOS 16/17 公屏消息塌成单行问题。
Turning point: 通过对比新旧代码 + ListPro 源码定位双重陷阱 —— RichText.size_changed 在 iOS WKWebView 上因净尺寸变化为 0 而不触发，叠加 ListPro `onChildSizeChanged` 在 `isScrolling` 时直接 return，导致 size_changed 即便后到也无法触发列表重排。
Result: B+C 组合修复：首渲同步兜底 applyMsgSize（不污染 data.height）+ scheduleOnce(0) 下一帧主动 recalcAfterLayout 绕开事件依赖；保留 commit 3c0c411 的复用路径强同步。安卓/Web 因 Chromium measureText 稳定，事件先到即生效，新增路径 no-op。

## Evidence

Recent paths:

- assets/Bundles/SpyGame/Script/Room/SpyRoomMsgItem.ts
- assets/Bundles/SpyGame/Script/Room/SpyChatLayer.ts
- assets/Script/Cocos/Components/UI/ListPro.ts

Notes:

- commit 3c0c411 删除了 SpyRoomMsgItem 首渲的同步测量、改纯依赖 RichText size_changed 异步纠正。在 iOS 14 Pro + iOS 16/17 上公屏消息频繁塌成单行；安卓/Web 正常。诊断后确定双重陷阱：iOS WKWebView Canvas2D measureText 同帧净 contentSize 变化为 0 时 size_changed 不触发，叠加 ListPro 滚动期 onChildSizeChanged 直接 return。改用 B+C 方案：保留复用路径的强同步 applyMsgSize + 恢复首渲同步兜底（不写回 data.height）+ scheduleOnce(0) 下一帧主动重测绕开事件依赖；经实机测试有效。
