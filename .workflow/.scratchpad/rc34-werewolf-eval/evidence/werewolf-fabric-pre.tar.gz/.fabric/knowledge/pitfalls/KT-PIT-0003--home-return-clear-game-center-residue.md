---
id: KT-PIT-0003
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:12:38.134Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

回首页恢复一般场景时优先清掉 GameCenter 与本地 rid 残留，否则界面已回首页但匹配仍被旧桌游 phase 拦截；同时避免依赖具体桌游 UIID，减少后续新增玩法的漏改点。src=5ceb58be

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log analysis. Origin: commit 5ceb58be (fix(main): 清理回首页时的桌游残留状态). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/Main

Notes:

- 回首页恢复一般场景时优先清掉 GameCenter 与本地 rid 残留，否则界面已回首页但匹配仍被旧桌游 phase 拦截；同时避免依赖具体桌游 UIID，减少后续新增玩法的漏改点。src=5ceb58be
