---
id: KT-PIT-0009
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-18T07:59:03.310Z
source_sessions: ["40a5086f-d3b7-4788-8e69-e91d428fc704"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Bundles/SpyGame/Script/Room/**/*.ts"]
---

## Summary

用户要做 fabric 全功能测试。会话先解了 .git/index.lock stale 阻塞，然后 commit 了 ae97ade3e（fix(spy): 抖音平台公屏聊天接入 platform 键盘，95 行）。该 commit 的核心 why：抖音平台 EditBox 自带键盘与 platform 键盘状态分离，导致 dismissKeyboard / 外部点击收键盘等收口逻辑失灵。修复方式：引入 TiktokEditBoxAdapter，并新增 hasActiveKeyboard() 同时识别 _isKeyboardLifted 与 isInputFocused 两条路径。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 测试 fabric 全功能闭环（discover → cite → edit → archive → review）。
Turning point: commit ae97ade3e 修复抖音平台键盘状态失灵，根因是 Cocos EditBox 自带键盘与 platform 键盘状态分离，单看 _isKeyboardLifted 不够。
Result: SpyBottomToolBar 引入 TiktokEditBoxAdapter 接管 platform 键盘；SpyChatLayer 新增 hasActiveKeyboard() 双轨判断，所有 dismissKeyboard 入口改用它。

## Evidence

Recent paths:

- assets/Bundles/SpyGame/Script/Room/SpyBottomToolBar.ts
- assets/Bundles/SpyGame/Script/Room/SpyChatLayer.ts
- assets/Script/MSDF

Notes:

- 用户要做 fabric 全功能测试。会话先解了 .git/index.lock stale 阻塞，然后 commit 了 ae97ade3e（fix(spy): 抖音平台公屏聊天接入 platform 键盘，95 行）。该 commit 的核心 why：抖音平台 EditBox 自带键盘与 platform 键盘状态分离，导致 dismissKeyboard / 外部点击收键盘等收口逻辑失灵。修复方式：引入 TiktokEditBoxAdapter，并新增 hasActiveKeyboard() 同时识别 _isKeyboardLifted 与 isInputFocused 两条路径。
