---
id: KT-PIT-0011
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-14T07:44:34.255Z
source_sessions: ["DBG-2026-05-14-spy-chat-richtext-openuserinfo"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: narrow
relevance_paths: ["assets/RemoteBundles/**/*.prefab", "assets/Script/Res/BundleManager.ts"]
---

## Summary

远程包 prefab 复用其它子包脚本时，Web/编辑器可能因脚本已加载表现正常，但微信小游戏移动端冷启动或重连路径会因脚本未注册导致组件缺失或 RichText click handler 不生效。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 定位 SpyChatLayer / SpyRoomChatDetail 中 RichTextHandler.openUserInfo 手机端偶现无法调用的问题。
Turning point: 发现 SpyRoomMsgItem.prefab 挂载的 RichTextHandler/EmitContentWidth 位于 VoiceRoom 子包，而 SpyGameRemote 隐式依赖只声明了 SpyGame。
Result: 将问题归因为跨包 prefab 脚本依赖遗漏；Web/已有缓存可能正常，移动端冷启动或重连路径更容易暴露。

## Evidence

Recent paths:

- assets/Script/Res/BundleManager.ts
- assets/Bundles/VoiceRoom/Script/room/RichTextHandler.ts
- assets/RemoteBundles/SpyGameRemote/Prefab/item/SpyRoomMsgItem.prefab
- assets/RemoteBundles/SpyGameRemote/Prefab/FooterLayer/SpyRoomChatDetail.prefab

Notes:

- 远程包 prefab 复用其它子包脚本时，Web/编辑器可能因脚本已加载表现正常，但微信小游戏移动端冷启动或重连路径会因脚本未注册导致组件缺失或 RichText click handler 不生效。
