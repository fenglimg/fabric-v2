---
id: KT-PIT-0002
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:12:30.409Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

gameWS 重连恢复时 this.room 可能残留上一轮桌游状态（如先玩卧底再进狼人），按旧 roomType 走错 recover 分支恢复到错误玩法 UI。修正：重连后始终先刷新服务端权威房间态再决定恢复路径。src=b2393e60

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log analysis. Origin: commit b2393e60 (fix: 修复 gameWS 重连后可能走错 recover 分支的问题). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/Game/Script

Notes:

- gameWS 重连恢复时 this.room 可能残留上一轮桌游状态（如先玩卧底再进狼人），按旧 roomType 走错 recover 分支恢复到错误玩法 UI。修正：重连后始终先刷新服务端权威房间态再决定恢复路径。src=b2393e60
