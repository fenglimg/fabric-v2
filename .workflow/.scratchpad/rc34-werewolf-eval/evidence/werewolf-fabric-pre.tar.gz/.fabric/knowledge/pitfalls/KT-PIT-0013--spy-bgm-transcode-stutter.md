---
id: KT-PIT-0013
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-19T09:11:46.043Z
source_sessions: ["67063371-304e-4f53-83af-a2466bcf0b07"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: narrow
relevance_paths: ["assets/RemoteBundles/SpyGameRemote/Audio/spy_game_prepare_bgm.mp3", "assets/RemoteBundles/SpyGameRemote/Audio/spy_game_prepare_bgm.mp3.meta", "assets/Script/Business/SpyGame/**/*.ts"]
intent_clues: ["when debugging mobile BGM stutter in SpyGame", "when changing SpyGameRemote Audio/*.mp3", "NOT for all BGM files by default"]
tech_stack: ["typescript", "cocos-creator", "wechat-minigame", "ffmpeg"]
impact: ["mobile BGM stutters during room entry", "unnecessary transcode of later BGM can reduce quality", "same-URL guard can mask lost audio context after reconnect"]
must_read_if: "touching SpyGameRemote audio BGM or SpyGameSoundUtil playback recovery"
---

## Summary

排查卧底准备阶段 BGM 手机端一卡一卡：对比狼人/卧底播放链路和音频参数，发现准备阶段在进房、SpyGameRemote 加载、语音频道 join 和 media 音频模式切换期间播放，原 44.1kHz/128kbps prepare_bgm 解码压力更高。用 ffmpeg 转为 12kHz/64kbps 后测试确认卡顿修复；其他 BGM 因播放时机更晚保持原参数。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 诊断 SpyGame 准备阶段 BGM 手机端卡顿，并确认与狼人音频链路/资源参数差异。
Turning point: 对比发现 prepare_bgm 原为 44.1kHz/128kbps/约 500KB，且播放时机叠加进房加载、语音频道 join、media 音频模式切换。
Fix: 使用 ffmpeg 转为 12kHz/64kbps/Stereo，并同步 meta duration=32.208；测试反馈卡顿修复。
Follow-up: 其他 SpyGame BGM 仍为 44.1kHz/128kbps，但播放更晚、环境稳定，当前测试无问题。

## Evidence

Recent paths:

- assets/RemoteBundles/SpyGameRemote/Audio/spy_game_prepare_bgm.mp3
- assets/RemoteBundles/SpyGameRemote/Audio/spy_game_prepare_bgm.mp3.meta
- assets/Script/Business/SpyGame/SpyGameSoundUtil.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts

Notes:

- 排查卧底准备阶段 BGM 手机端一卡一卡：对比狼人/卧底播放链路和音频参数，发现准备阶段在进房、SpyGameRemote 加载、语音频道 join 和 media 音频模式切换期间播放，原 44.1kHz/128kbps prepare_bgm 解码压力更高。用 ffmpeg 转为 12kHz/64kbps 后测试确认卡顿修复；其他 BGM 因播放时机更晚保持原参数。
