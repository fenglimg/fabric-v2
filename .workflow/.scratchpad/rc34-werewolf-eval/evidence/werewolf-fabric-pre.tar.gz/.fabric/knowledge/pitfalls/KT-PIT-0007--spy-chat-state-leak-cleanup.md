---
id: KT-PIT-0007
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:17:14.725Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

卧底房：公屏非座位发言者资料缺失需要单独取用户信息；退房后聊天状态残留会污染下一局，必须在房间退出链路里显式清理聊天 store。src=0ea67aa9

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log. Origin: commit 0ea67aa9 (fix(spy): 修复卧底房公屏非座位发言者资料缺失与退房后聊天状态残留).

## Evidence

Recent paths:

- assets/Bundles/SpyGame
- assets/Bundles/Chat

Notes:

- 卧底房：公屏非座位发言者资料缺失需要单独取用户信息；退房后聊天状态残留会污染下一局，必须在房间退出链路里显式清理聊天 store。src=0ea67aa9
