---
id: KT-PIT-0001
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:17:17.978Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

合并 atlas 时若包含半透明切图，必须开启 premultiplyAlpha，否则半透明边缘会出现黑边；这是 Cocos 图集预乘 alpha 的渲染坑。src=b713d74f

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log. Origin: commit b713d74f (chore(spy-game): 更新 TV 背景图并移除废弃切图; premultiplyAlpha fix).

## Evidence

Recent paths:

- assets/Bundles/SpyGame/atlas

Notes:

- 合并 atlas 时若包含半透明切图，必须开启 premultiplyAlpha，否则半透明边缘会出现黑边；这是 Cocos 图集预乘 alpha 的渲染坑。src=b713d74f
