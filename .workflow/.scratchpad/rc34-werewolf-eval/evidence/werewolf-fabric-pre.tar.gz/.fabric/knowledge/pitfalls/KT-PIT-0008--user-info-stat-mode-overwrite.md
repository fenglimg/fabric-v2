---
id: KT-PIT-0008
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:12:41.827Z
source_sessions: ["fabric-import-2026-05-13"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

用户信息弹窗：renderUser 写入的 total/win_rate 会与 refreshSimpleGameStat 按玩法拉取的数据冲突，使局数与胜率被主页战绩错误覆盖。不要让主页战绩覆盖玩法简要战绩。src=6909d7c4

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log analysis. Origin: commit 6909d7c4 (fix(game): 用户信息弹窗避免主页战绩覆盖简要战绩). No live session — see commit body for full context.

## Evidence

Recent paths:

- assets/Bundles/Game/Script
- assets/Bundles/Common

Notes:

- 用户信息弹窗：renderUser 写入的 total/win_rate 会与 refreshSimpleGameStat 按玩法拉取的数据冲突，使局数与胜率被主页战绩错误覆盖。不要让主页战绩覆盖玩法简要战绩。src=6909d7c4
