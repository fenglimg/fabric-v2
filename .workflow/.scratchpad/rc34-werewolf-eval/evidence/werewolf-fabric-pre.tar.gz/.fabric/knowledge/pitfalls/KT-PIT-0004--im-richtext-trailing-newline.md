---
id: KT-PIT-0004
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-13T11:17:29.461Z
source_sessions: ["fabric-import-2026-05-13-r2"]
proposed_reason: diagnostic-then-fix
tags: []
---

## Summary

IM 系统消息与公告富文本创建前必须去除末尾换行，否则会渲染出空行/底部留白。src=3b959b87

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Imported from git log. Origin: commit 3b959b87 (fix(im): 系统与公告富文本创建前去除末尾换行).

## Evidence

Recent paths:

- assets/Script/IM

Notes:

- IM 系统消息与公告富文本创建前必须去除末尾换行，否则会渲染出空行/底部留白。src=3b959b87
