---
type: models
maturity: draft
layer: team
created_at: 2026-05-21T07:38:43.770Z
source_sessions: ["d2da7a44-b9fe-43b0-a5df-c3a7e85ce6e2"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Bundles/SpyGame/Script/Record/**/*.ts", "assets/Proto/spy.proto", "tests/assets/Bundles/SpyGame/Script/Record/__tests__/**/*.ts"]
intent_clues: ["改 SpyGameRecordDetailModel.createPlayerDesc 或弃票/投票阶段判定时", "新增 spy.proto GamerDesc 字段或 GamerRoundStatus 枚举时", "NOT for live 投票阶段 UI (SpyPlayerControl 用另一套实时态)", "NOT for PK 参与者判定(见 KT-MOD-0017)"]
tech_stack: ["typescript", "cocos-creator", "spy-game", "protobuf"]
impact: ["DEAD_CURRENT 玩家(本轮被票死)若未投票，会在战绩弃牌堆里漏显示，用户反馈复盘信息缺失", "若把 ALIVE 当弃票充要条件，未来 GamerRoundStatus 枚举新增成员(如 BOMB_OUT)会再次踩同型坑"]
must_read_if: "改动 SpyGameRecordDetailModel 弃票/投票相关判定，或 spy.proto GamerDesc.status 语义"
x-fabric-idempotency-key: sha256:44a9e63b4fd620e11b8be42cb12db67964a27506fe076ac3b7b799c1d41e46b9
---

## Summary

用户反馈 Spy 战绩里第一轮 A 被票死 (DEAD_CURRENT) 但 A 没投票，A 没出现在弃牌堆里。排查发现 SpyGameRecordDetailModel.createPlayerDesc 的 isAbstain 判定要求 status===ALIVE，把 DEAD_CURRENT 漏掉了；同时 proto 注释把规则写成 `status == ALIVE && !is_tie_gamer`，反例列表却只排除了 DEAD_HISTORIC，三者(code + proto 注释 + 单元测试)一起把 bug 固化。修复：放宽为 ALIVE || DEAD_CURRENT 都算"本轮有投票权"，同步改 proto 注释 + 测试断言。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 修复 Spy 战绩历史记录里 DEAD_CURRENT 玩家的弃票没进弃牌堆的显示 bug。
Turning point: 对比 proto 注释 `弃票判定: vote_over==false && status==ALIVE && !is_tie_gamer` 与反例列表(只排除 DEAD_HISTORIC 和 is_tie_gamer)发现规则字面与反例语义不一致——反例列表才是契约真相: 弃票应按"本轮有投票权(ALIVE 或 DEAD_CURRENT)"判定，DEAD_CURRENT(本轮被票死者)投票时仍活着、未投票即弃票。
Result: SpyGameRecordDetailModel.createPlayerDesc 放宽为 hadVoteRightThisRound = ALIVE||DEAD_CURRENT，proto 注释 + 单元测试断言同步修正(原测试把 DEAD_CURRENT 当非弃票，是固化了 bug 的断言)。

## Evidence

Recent paths:

- assets/Bundles/SpyGame/Script/Record/SpyGameRecordDetailModel.ts
- assets/Proto/spy.proto
- tests/assets/Bundles/SpyGame/Script/Record/__tests__/SpyGameRecordDetailModel.test.ts

Notes:

- 用户反馈 Spy 战绩里第一轮 A 被票死 (DEAD_CURRENT) 但 A 没投票，A 没出现在弃牌堆里。排查发现 SpyGameRecordDetailModel.createPlayerDesc 的 isAbstain 判定要求 status===ALIVE，把 DEAD_CURRENT 漏掉了；同时 proto 注释把规则写成 `status == ALIVE && !is_tie_gamer`，反例列表却只排除了 DEAD_HISTORIC，三者(code + proto 注释 + 单元测试)一起把 bug 固化。修复：放宽为 ALIVE || DEAD_CURRENT 都算"本轮有投票权"，同步改 proto 注释 + 测试断言。
