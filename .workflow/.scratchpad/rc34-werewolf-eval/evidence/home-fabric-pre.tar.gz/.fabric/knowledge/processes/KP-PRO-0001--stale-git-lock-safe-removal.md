---
id: KP-PRO-0001
type: processes
maturity: draft
layer: personal
created_at: 2026-05-18T07:59:28.459Z
source_sessions: ["40a5086f-d3b7-4788-8e69-e91d428fc704"]
proposed_reason: diagnostic-then-fix
tags: []
relevance_scope: broad
relevance_paths: []
---

## Summary

用户报 git pull / git commit 全失败，error: could not write index。诊断流程：lsof 确认无进程持有 lock；ls 检查 lock 0 字节（无 transaction 数据写入）；ps aux 排除活的 git 进程（gitstatusd / GitKraken MCP / Cursor gitWorker 是只读守护进程，不算）；时间戳显著陈旧。四项同时满足才安全 rm，然后 stash → pull → pop 恢复工作。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 测试 fabric 全功能；前置阻塞——git 全失败。
Turning point: 发现 .git/index.lock 是 5 分钟前的 0 字节 stale lock，PID 27053 早已死亡。
Result: lsof + ps 双重确认安全后删除，stash/pull/pop 恢复工作。该流程通用于所有 macOS git stale lock 场景。

## Evidence

Recent paths:

- .git/index.lock

Notes:

- 用户报 git pull / git commit 全失败，error: could not write index。诊断流程：lsof 确认无进程持有 lock；ls 检查 lock 0 字节（无 transaction 数据写入）；ps aux 排除活的 git 进程（gitstatusd / GitKraken MCP / Cursor gitWorker 是只读守护进程，不算）；时间戳显著陈旧。四项同时满足才安全 rm，然后 stash → pull → pop 恢复工作。
