---
id: KT-PIT-0017
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-27T08:21:26.135Z
source_sessions: ["e4c7c14b-4a97-4b0a-97c2-ec8ba9fa7f5b"]
proposed_reason: wrong-turn-revert
summary: "用户基于记忆指出\"微信小游戏端应当同时存在 GME 和火山 RTC 两条路径\",纠正了我此前只看 Main.ts 平台 if 得出的\"微信→RTC\"过简结论。深挖后确认真正的 SDK 选型是两层决策:Main.ts 设默认 + 服务端 voice_type 字段按房间动态切换。"
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Script/Main.ts", "assets/Script/Business/VoiceChat/VoiceChatManager.ts", "assets/Script/Business/VoiceChat/IVoiceChat.ts", "assets/Script/Business/SpyGame/SpyGameManager.ts", "assets/Script/Business/VoiceRoom/Core/VoiceRoomManager.ts"]
intent_clues: ["when explaining which voice SDK a room uses", "when debugging why a given room joins GME instead of RTC (or vice versa)", "when planning to add a new platform/SDK branch", "NOT for unrelated cc.sys.platform branches outside voice"]
tech_stack: ["typescript", "cocos-creator", "wechat-minigame"]
impact: ["misdiagnose voice-routing bugs by only inspecting Main.ts", "miss that server-pushed voice_type can flip GME⇄RTC mid-session"]
must_read_if: "about to reason about which voice SDK runs in a given room/platform"
---

## Summary

用户基于记忆指出"微信小游戏端应当同时存在 GME 和火山 RTC 两条路径",纠正了我此前只看 Main.ts 平台 if 得出的"微信→RTC"过简结论。深挖后确认真正的 SDK 选型是两层决策:Main.ts 设默认 + 服务端 voice_type 字段按房间动态切换。

## Why proposed

wrong-turn-revert — 尝试某路径后回退，错误路径本身是值得记录的 pitfall。

## Session context

本会话连续两轮我都给出过简的"微信端→火山 RTC,其它端→GME"结论,被用户纠正后才补出真相:Main.ts:201 的平台 if 只设启动期默认 adapter,真正的 SDK 选型发生在 VoiceChatManager.runJoin 里,按业务调 join 时透传的 sdkType(来自服务端 voice_type 字段)执行 await useGME()/useRTC()/useVoIP()。微信小游戏端 GME 与火山 RTC 是并存双路径,后端可按房间切换。归档为 pitfall 避免后续再踩。配套入门索引见 [[voice-subsystem-overview]]。

## Evidence

Recent paths:

- assets/Script/Main.ts
- assets/Script/Business/VoiceChat/VoiceChatManager.ts
- assets/Script/Business/VoiceChat/IVoiceChat.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Script/Business/SpyGame/SpyGameModel.ts
- assets/Script/Business/VoiceRoom/Core/VoiceRoomManager.ts
- assets/Script/Server/Socket/WebScoketInterface.ts
- assets/Script/Server/Http/RoomApi.ts

Notes:

- 用户基于记忆指出"微信小游戏端应当同时存在 GME 和火山 RTC 两条路径",纠正了我此前只看 Main.ts 平台 if 得出的"微信→RTC"过简结论。深挖后确认真正的 SDK 选型是两层决策:Main.ts 设默认 + 服务端 voice_type 字段按房间动态切换。
