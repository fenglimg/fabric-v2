---
id: KT-PIT-0018
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-27T08:21:41.185Z
source_sessions: ["e4c7c14b-4a97-4b0a-97c2-ec8ba9fa7f5b"]
proposed_reason: new-dependency-or-pattern
summary: "用户要求把全部 RTC/语音相关概念查清楚,过程中暴露出多个易混点:文件名带 \"Wechat\" 实则封装火山 RTC、项目里裸出现的 \"RTC\" 通常指火山而非 TRTC、TRTC token 只是腾讯系签名复用给 GME。"
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Script/Business/VoiceChat/RTCSDK/WeChat/**", "assets/Script/Business/VoiceChat/Adapter/RTC/**"]
intent_clues: ["when reading code under assets/Script/Business/VoiceChat/RTCSDK/", "when debugging RTC errors and choosing which vendor's doc to consult", "NOT for the TRTC token API which is genuinely Tencent (only the sign endpoint, GME consumer)"]
tech_stack: ["typescript", "cocos-creator", "wechat-minigame", "volcengine-rtc"]
impact: ["consult wrong vendor docs / error-code tables", "misroute bug reports to Tencent GME team when the issue is VolcEngine RTC"]
must_read_if: "about to look up vendor docs / error codes for anything named *RTC* in this project"
---

## Summary

用户要求把全部 RTC/语音相关概念查清楚,过程中暴露出多个易混点:文件名带 "Wechat" 实则封装火山 RTC、项目里裸出现的 "RTC" 通常指火山而非 TRTC、TRTC token 只是腾讯系签名复用给 GME。

## Why proposed

new-dependency-or-pattern — 引入新依赖 / 新模式 / 新命名约定。

## Session context

梳理语音子系统时发现的命名陷阱:Business/VoiceChat/RTCSDK/WeChat/WechatRTCEngine.ts 名字带 "Wechat" 但封装的厂商是字节火山 RTC(底层调 wx.getRtcEngine() 是微信小游戏暴露的火山 RTC 引擎),不是腾讯系。同理项目代码里裸出现的 "RTC" 几乎都=火山 RTC,与 api.getTrtcToken() 那个 TRTC(腾讯,给 GME 用)无关。新人按名字想当然会把厂商归属搞反,查错文档/错误码表。配套架构索引见 [[voice-subsystem-overview]]。

## Evidence

Recent paths:

- assets/Script/Business/VoiceChat/RTCSDK/WeChat/WechatRTCEngine.ts
- assets/Script/Business/VoiceChat/RTCSDK/WeChat/WechatRTCTypes.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/WeChatRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/BaseRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/GMEAdapter.ts
- assets/Script/Server/Http/ConfigApi.ts

Notes:

- 用户要求把全部 RTC/语音相关概念查清楚,过程中暴露出多个易混点:文件名带 "Wechat" 实则封装火山 RTC、项目里裸出现的 "RTC" 通常指火山而非 TRTC、TRTC token 只是腾讯系签名复用给 GME。
