---
id: KT-PIT-0015
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-28T02:49:17.944Z
source_sessions: ["dc96061a-56e3-4bbd-9256-494e2f0368ca"]
proposed_reason: diagnostic-then-fix
summary: "实现卧底 BGM 客户端音量显示+增量调节后，用户反馈「音量调到 0% 时又跳回 100%」。排查发现各平台音频引擎 helper 用 `options.volume || 1` 设置音量，0 被当 falsy 回退成满音量。"
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Framework/Script/Audio/**"]
intent_clues: ["when setting audio/playback volume with a default fallback", "when a numeric param treats 0 as a valid value", "NOT for params where 0 is genuinely invalid"]
tech_stack: ["typescript", "cocos-creator"]
impact: ["volume=0 (mute) silently plays at full 100% volume"]
must_read_if: "editing volume/gain handling in assets/Framework/Script/Audio/*AudioEngineHelper.ts"
---

## Summary

实现卧底 BGM 客户端音量显示+增量调节后，用户反馈「音量调到 0% 时又跳回 100%」。排查发现各平台音频引擎 helper 用 `options.volume || 1` 设置音量，0 被当 falsy 回退成满音量。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

为卧底 BGM 新增客户端音量显示与 +5/+1/-1/-5 增量调节。调到 0% 时实际以 100% 播放——根因不在新增的 SpyGameSoundUtil 调节逻辑，而在底层三个音频引擎 helper（CCC/Tt/Wx）统一用 `options.volume || 1`，把合法值 0 当 falsy 吞掉回退成 1。修复：三处改为 `options.volume ?? 1`，仅 undefined/null 才回退，0 保持静音。

## Evidence

Recent paths:

- assets/Framework/Script/Audio/CCCAudioEngineHelper.ts
- assets/Framework/Script/Audio/TtAudioEngineHelper.ts
- assets/Framework/Script/Audio/WxAudioEngineHelper.ts
- assets/Script/Business/SpyGame/SpyGameSoundUtil.ts
- assets/Bundles/SpyGame/Script/SpyGameRoomUI.ts

Notes:

- 实现卧底 BGM 客户端音量显示+增量调节后，用户反馈「音量调到 0% 时又跳回 100%」。排查发现各平台音频引擎 helper 用 `options.volume || 1` 设置音量，0 被当 falsy 回退成满音量。
