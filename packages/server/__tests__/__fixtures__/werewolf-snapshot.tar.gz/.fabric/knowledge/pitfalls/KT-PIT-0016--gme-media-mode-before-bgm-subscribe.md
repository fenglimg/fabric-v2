---
id: KT-PIT-0016
type: pitfalls
maturity: draft
layer: team
created_at: 2026-05-28T03:00:14.851Z
source_sessions: ["269d2efb-ded8-479b-bf40-7bce1b2a37cb"]
proposed_reason: diagnostic-then-fix
summary: "测试反馈卧底接入服务器 BGM 后有很大电流声、音质变差；服务器同学怀疑 GME 没用媒体接收模式。排查确认：GME 订阅 BGM 机器人时若仍在语音音量类型，接收音质差。决定（方案A）在 SpyGameManager 订阅前 await 切到 media 音量类型，尽量不动既有基建。"
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Script/Business/SpyGame/SpyGameManager.ts", "assets/Script/Business/VoiceChat/**"]
intent_clues: ["when subscribing a server BGM robot over GME/RTC", "when debugging static/current noise or poor music quality in voice rooms", "NOT for pure voice (no music) channels"]
tech_stack: ["typescript", "cocos-creator", "gme", "volc-rtc"]
impact: ["server BGM received with heavy current noise / degraded quality", "music sounds fine only after switching to media audio volume type"]
must_read_if: "subscribing a BGM/music robot over GME or switching audio volume type in SpyGameManager/VoiceChat adapters"
---

## Summary

测试反馈卧底接入服务器 BGM 后有很大电流声、音质变差；服务器同学怀疑 GME 没用媒体接收模式。排查确认：GME 订阅 BGM 机器人时若仍在语音音量类型，接收音质差。决定（方案A）在 SpyGameManager 订阅前 await 切到 media 音量类型，尽量不动既有基建。

## Why proposed

diagnostic-then-fix — 诊断过程发现新模式或踩坑，修复后值得沉淀。

## Session context

Session goal: 修复卧底订阅服务器 BGM 后的电流声/音质差。
Turning point: 定位到 GME 默认以语音(voice)音量类型接收，订阅 BGM 机器人前未切 media，导致语音降噪/编码劣化音乐音质。
Fix: 在 SpyGameManager 订阅 BGM 机器人前 await 切到 media 音量类型（方案A，收口在 SpyGameManager，避免动 VoiceRoom/婚礼房既有链路）。commit a1215311f。
约束：用户明确要求尽量不影响之前基建，风险控制优先。

## Evidence

Recent paths:

- assets/Script/Business/VoiceChat/Adapter/RTC/WeChatRTCAdapter.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Script/Business/VoiceRoom/Core/VoiceRoomManager.ts
- assets/Script/Business/VoiceChat/IVoiceChat.ts

Notes:

- 测试反馈卧底接入服务器 BGM 后有很大电流声、音质变差；服务器同学怀疑 GME 没用媒体接收模式。排查确认：GME 订阅 BGM 机器人时若仍在语音音量类型，接收音质差。决定（方案A）在 SpyGameManager 订阅前 await 切到 media 音量类型，尽量不动既有基建。
