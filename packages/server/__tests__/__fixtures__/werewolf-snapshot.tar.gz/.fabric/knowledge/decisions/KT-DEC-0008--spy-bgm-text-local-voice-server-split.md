---
id: KT-DEC-0008
type: decisions
maturity: draft
layer: team
created_at: 2026-05-28T03:00:29.812Z
source_sessions: ["4a01db6e-ecbe-4cfb-b43e-67cd51b6a6e5"]
proposed_reason: decision-confirmation
summary: "需求变更：文字版走之前注释的本地 BGM 播放，语音版走服务器推流；文字版本地 BGM 是否播放由房间 spy_bgm_switch 控制。describeMode 在房间存续期可由 SpyRoomSetter 动态切换，需处理文字/语音互切时本地 BGM 与服务器 BGM 的各种切换问题，切到语音版还要考虑重新订阅音频。"
tags: []
relevance_scope: narrow
relevance_paths: ["assets/Script/Business/SpyGame/SpyGameManager.ts", "assets/Script/Business/SpyGame/SpyGameSoundUtil.ts"]
intent_clues: ["when changing SpyGame BGM playback or phase music", "when handling text/voice (describeMode) room switching", "NOT for non-spy game BGM"]
tech_stack: ["typescript", "cocos-creator"]
impact: ["text+voice BGM may double-play or fight the RTC channel if not unified", "describeMode switch can leave stale local BGM playing"]
must_read_if: "touching SpyGame BGM playback, applyBgmPolicy, or describeMode text/voice switching"
---

## Summary

需求变更：文字版走之前注释的本地 BGM 播放，语音版走服务器推流；文字版本地 BGM 是否播放由房间 spy_bgm_switch 控制。describeMode 在房间存续期可由 SpyRoomSetter 动态切换，需处理文字/语音互切时本地 BGM 与服务器 BGM 的各种切换问题，切到语音版还要考虑重新订阅音频。

## Why proposed

decision-confirmation — ≥2 候选方案经权衡后确认选型，需保留 rationale。

## Session context

Session goal: 确立卧底 BGM 的文字版/语音版分流策略。
Turning point: 用户确认整体路径——文字版本地 audioKit 播 BGM、语音版服务器 RTC 机器人推流、由 spy_bgm_switch 控制文字版本地 BGM 开关。
Decision: 所有 BGM 入口（phase 变化 / 前后台 / 断线重连 / RoomInfoPush 模式切换 / switch 变化）统一收口到 SpyGameManager.applyBgmPolicy；语音版分支只 stopBgm 本地、不与服务器机器人抢通道；describeMode 动态切换由该策略兜底。commit 94cbdb84d。

## Evidence

Recent paths:

- assets/Script/Business/SpyGame/SpyGameSoundUtil.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Bundles/SpyGame/Script/SpyGameRoomUI.ts

Notes:

- 需求变更：文字版走之前注释的本地 BGM 播放，语音版走服务器推流；文字版本地 BGM 是否播放由房间 spy_bgm_switch 控制。describeMode 在房间存续期可由 SpyRoomSetter 动态切换，需处理文字/语音互切时本地 BGM 与服务器 BGM 的各种切换问题，切到语音版还要考虑重新订阅音频。
