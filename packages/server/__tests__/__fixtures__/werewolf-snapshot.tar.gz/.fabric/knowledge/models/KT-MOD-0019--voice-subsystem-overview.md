---
id: KT-MOD-0019
type: models
maturity: draft
layer: team
created_at: 2026-05-27T08:21:10.980Z
source_sessions: ["e4c7c14b-4a97-4b0a-97c2-ec8ba9fa7f5b"]
proposed_reason: decision-confirmation
summary: "用户三轮提问拉通项目语音子系统全貌:先问 GME / 火山 RTC / 其它是什么,再纠正\"微信端不只是 RTC、应同时有 GME 和火山 RTC 双路径\",最后要求把全部相关概念在当前项目中查清楚。归档目的是沉淀成可复用的入门索引。"
tags: []
relevance_scope: broad
intent_clues: ["when first touching VoiceChat / RTC / GME / VoIP code in this project", "when debugging why a room uses one SDK vs another", "NOT for unrelated audio playback (cc.audioEngine) questions"]
tech_stack: ["typescript", "cocos-creator", "wechat-minigame", "bytedance-minigame", "android-jsbridge"]
impact: ["misattribute SDK vendor (Tencent vs ByteDance) leading to wrong docs/error-code references", "miss the two-layer routing and chase platform-only branches"]
must_read_if: "about to edit anything under assets/Script/Business/VoiceChat/** or related Lib/GME/**"
---

## Summary

用户三轮提问拉通项目语音子系统全貌:先问 GME / 火山 RTC / 其它是什么,再纠正"微信端不只是 RTC、应同时有 GME 和火山 RTC 双路径",最后要求把全部相关概念在当前项目中查清楚。归档目的是沉淀成可复用的入门索引。

## Why proposed

decision-confirmation — ≥2 候选方案经权衡后确认选型，需保留 rationale。

## Session context

三轮 Q&A 拉通项目语音/RTC 子系统的概念地图。第二轮用户基于"微信端似乎是双路径"的记忆纠正了我过简的"微信→RTC、原生→GME"答案,补出真正的两层决策模型(Main.ts 默认 + 服务端 voice_type)。第三轮要求做地毯式盘点,产出涵盖 SDK 厂商/Adapter 抽象/协议字段/平台矩阵/枚举/BGM 机器人/事件错误码/JsBridge 的完整术语表。本条作为入口索引,后续具体陷阱独立归档(see [[voice-sdk-two-layer-routing]], [[wechat-rtc-engine-naming-trap]])。

## Evidence

Recent paths:

- assets/Script/Main.ts
- assets/Script/Business/VoiceChat/VoiceChatManager.ts
- assets/Script/Business/VoiceChat/IVoiceChat.ts
- assets/Script/Business/VoiceChat/Adapter/GMEAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/BaseRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/WeChatRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/DouyinRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/AndroidRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/VoIPAdapter.ts
- assets/Script/Business/VoiceChat/RTCSDK/WeChat/WechatRTCEngine.ts
- assets/Script/Business/VoiceChat/RTCSDK/WeChat/WechatRTCTypes.ts
- assets/Script/Business/VoiceChat/DevSDK/AndroidGME.ts
- assets/Script/Business/VoiceChat/DevSDK/DevGME.ts
- assets/Script/Lib/GME/gmeError.ts
- assets/Script/Lib/GME/gme-wx.ts
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Script/Business/VoiceRoom/Core/VoiceRoomManager.ts
- assets/Script/Server/Http/ConfigApi.ts
- assets/Script/Server/Socket/WebScoketInterface.ts
- assets/Script/Bridge/JsBridge.ts

Notes:

- 用户三轮提问拉通项目语音子系统全貌:先问 GME / 火山 RTC / 其它是什么,再纠正"微信端不只是 RTC、应同时有 GME 和火山 RTC 双路径",最后要求把全部相关概念在当前项目中查清楚。归档目的是沉淀成可复用的入门索引。
