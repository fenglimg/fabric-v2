---
id: KT-GLD-0012
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-27T06:30:05.222Z
source_sessions: ["019e6803-f7a6-7492-bdb7-9715e6d7f33c"]
proposed_reason: explicit-user-mark
summary: "用户显式要求归档 Cocos 生命周期约束：不要在 onDestroy 中操作 this.node 或 this.node 相关对象，因为 onDestroy 执行时节点已经处于销毁阶段。"
tags: []
relevance_scope: broad
relevance_paths: []
intent_clues: ["when editing Cocos component lifecycle methods", "when adding cleanup logic in onDestroy", "NOT for cleanup that does not touch node state"]
tech_stack: ["typescript", "cocos-creator"]
impact: ["touching destroyed nodes in onDestroy can cause invalid node access", "cleanup code may crash or behave unpredictably during component teardown"]
must_read_if: "touching onDestroy in Cocos component scripts"
---

## Summary

用户显式要求归档 Cocos 生命周期约束：不要在 onDestroy 中操作 this.node 或 this.node 相关对象，因为 onDestroy 执行时节点已经处于销毁阶段。

## Why proposed

explicit-user-mark — 用户显式标记需归档（always / never / 下次注意 等规范性语言）。

## Session context

本轮完成了卧底房间背景音乐开关的协议、状态和设置面板接入，并提交为 9df8ef6d。
用户随后指出一个需要沉淀的 Cocos 生命周期约束。
约束内容是：不要在 onDestroy 阶段操作 this.node 或 this.node 相关对象，因为此时节点已经销毁或处于销毁流程。

## Evidence

Recent paths:

- assets/Bundles/Home/Script/SpyRoomSetter.ts
- assets/RemoteBundles/SpyGameRemote/Prefab/HoverLayer/SpyRoomSetterPanel.prefab
- assets/Script/Business/SpyGame/SpyGameManager.ts
- assets/Script/Business/SpyGame/SpyGameModel.ts

Notes:

- 用户显式要求归档 Cocos 生命周期约束：不要在 onDestroy 中操作 this.node 或 this.node 相关对象，因为 onDestroy 执行时节点已经处于销毁阶段。
