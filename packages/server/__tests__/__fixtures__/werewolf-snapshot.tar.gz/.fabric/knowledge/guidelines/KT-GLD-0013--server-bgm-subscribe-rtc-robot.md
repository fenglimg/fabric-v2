---
id: KT-GLD-0013
type: guidelines
maturity: draft
layer: team
created_at: 2026-05-27T06:58:37.238Z
source_sessions: ["codex-2026-05-27-spy-rtc-music-robot"]
proposed_reason: explicit-user-mark
summary: "用户要求参考婚礼房 weddingroom 的阶段音乐订阅方式，确认 SpyGameRoom 的服务器播放 BGM 也需要在进入 RTC 语音房后订阅音乐机器人，否则火山 RTC 听不到。随后要求将婚礼房 RTC 订阅逻辑与 SpyGameRoom 订阅音乐机器人相关逻辑整理归档。"
tags: []
relevance_scope: broad
relevance_paths: []
intent_clues: ["when adding server-played BGM to RTC rooms", "when local BGM playback is disabled for a game room", "when debugging Volc RTC room music being inaudible"]
tech_stack: ["typescript", "cocos-creator", "volc-rtc"]
impact: ["server BGM may be playing but clients hear silence in RTC", "phase music can be missed after entering or recovering a room"]
must_read_if: "touching RTC room BGM playback or subscribeMusicRobotIfNeeded flows"
---

## Summary

用户要求参考婚礼房 weddingroom 的阶段音乐订阅方式，确认 SpyGameRoom 的服务器播放 BGM 也需要在进入 RTC 语音房后订阅音乐机器人，否则火山 RTC 听不到。随后要求将婚礼房 RTC 订阅逻辑与 SpyGameRoom 订阅音乐机器人相关逻辑整理归档。

## Why proposed

explicit-user-mark — 用户显式标记需归档（always / never / 下次注意 等规范性语言）。

## Session context

本会话先接入了卧底房 spy_bgm_switch 开关，随后排查到 SpyGameSoundUtil 已停止本地 BGM 播放，BGM 改由服务器推流。
对照 VoiceRoom/Wedding 现有链路，MusicManager 和 VoiceRoomViewModel 会在音乐状态同步或 RTC 进房成功后调用 subscribeMusicRobotIfNeeded。
最终在 SpyGameManager.joinVoiceChannel 成功后补订阅 RTC 音乐机器人，并提交 00fe6bac8。

## Evidence

Recent paths:

- assets/Script/Business/SpyGame/SpyGameManager.ts
- tests/assets/Script/Business/SpyGame/__tests__/SpyGameManager.test.ts
- assets/Bundles/VoiceRoom/Script/room/VoiceRoomMain/Model/VoiceRoomViewModel.ts
- assets/Bundles/VoiceRoom/Script/Music/Script/Manager/MusicManager.ts
- assets/Script/Business/VoiceChat/Adapter/RTC/WeChatRTCAdapter.ts
- assets/Script/Business/VoiceChat/Adapter/BaseVoiceAdapter.ts
- assets/Script/Business/SpyGame/SpyGameSoundUtil.ts

Notes:

- 用户要求参考婚礼房 weddingroom 的阶段音乐订阅方式，确认 SpyGameRoom 的服务器播放 BGM 也需要在进入 RTC 语音房后订阅音乐机器人，否则火山 RTC 听不到。随后要求将婚礼房 RTC 订阅逻辑与 SpyGameRoom 订阅音乐机器人相关逻辑整理归档。
